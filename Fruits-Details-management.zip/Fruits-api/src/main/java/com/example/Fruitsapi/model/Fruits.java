package com.example.Fruitsapi.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Fruits {

	@Id
	private int Id;
	private String Name;
	private String Color;
	private String Quality;
	private int price;

	public Fruits() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Fruits(int id, String name, String color, String quality, int price) {
		super();
		Id = id;
		Name = name;
		Color = color;
		Quality = quality;
		this.price = price;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getColor() {
		return Color;
	}

	public void setColor(String color) {
		Color = color;
	}

	public String getQuality() {
		return Quality;
	}

	public void setQuality(String quality) {
		Quality = quality;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Fruits [Id=" + Id + ", Name=" + Name + ", Color=" + Color + ", Quality=" + Quality + ", price=" + price
				+ "]";
	}

}
