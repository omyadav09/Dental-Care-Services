package com.example.Fruitsapi.controller;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.Fruitsapi.model.Fruits;

@Controller
public class Fruits_Controller {

	@Autowired
	SessionFactory sf;
	
	@RequestMapping("/")
	public String home()
	{
		return "home";
	}
	
	@RequestMapping("/addpage")
	public String add()
	{
		return "add";
	}
	
	@RequestMapping("/add")
	public String addtoDB(Fruits fruit, Model model)
	{
			Session ss = sf.openSession();
			Transaction tx = ss.beginTransaction();
			
			String msg="Fruit Details Added Succesfully";
			
			ss.save(fruit);
			tx.commit();
			model.addAttribute("msg",msg);
			return "add";
		
			
	}
	
	@RequestMapping("/deletepage")
	public String deletepage()
	{
		return "delete";
	}
	
	@RequestMapping("/delete")
	public String delete(int id, Model model)
	{
		System.out.println(id);
		if(id>0&&id!=0)
		{
			Session ss=sf.openSession();
			Transaction tx = ss.beginTransaction();
			
		    Fruits fruit = ss.get(Fruits.class, id);
		    ss.remove(fruit);
		    tx.commit();
		    model.addAttribute("msg",fruit+"One Fruit details deleted");
		}else {
			model.addAttribute("msg","Enter Valid Id");
		}
		
	    return "delete";
	}
	
	@RequestMapping("/allfruits")
	public List<Fruits> allfruits(Model model)
	{
		Session ss = sf.openSession();
		Query qs = ss.createQuery("from Fruits");
		List<Fruits> list = qs.list();
		
		System.out.println("Fruits Details");
		for(Fruits f:list)
		{
	      System.out.println(f.getId()+" "+f.getName()+" "+f.getColor()+" "+f.getQuality()+" "+f.getPrice());
		}
		model.addAttribute("msg",list);
		return list;
	}
}
