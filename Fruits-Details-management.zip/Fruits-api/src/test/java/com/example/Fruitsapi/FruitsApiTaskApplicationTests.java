package com.example.Fruitsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruitsApiTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
